from collections import deque

from PIL import Image as PILImage

from kivy.app import App
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.camera import Camera
from kivy.uix.widget import Widget
from kivy.uix.label import Label

from kivy.graphics import Color, Ellipse, Line, Rectangle
from kivy.clock import Clock
from kivy.core.audio import SoundLoader


# ============================================================
# HUMAN ON BED
# ============================================================

class BedHumanOverlay(Widget):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.state = "aware"

        self.bind(
            size=self.draw_scene,
            pos=self.draw_scene
        )

    def set_scare_state(self, new_state):
        self.state = new_state
        self.draw_scene()

    def draw_scene(self, *args):

        self.canvas.clear()

        with self.canvas:

            w, h = self.size

            cx = self.pos[0] + w / 2
            cy = self.pos[1] + h / 2

            # ------------------------------------------------
            # BED
            # ------------------------------------------------

            Color(0.2, 0.15, 0.1, 0.85)

            Rectangle(
                pos=(cx - 160, cy - 220),
                size=(320, 180)
            )

            # ------------------------------------------------
            # PILLOW
            # ------------------------------------------------

            Color(0.85, 0.85, 0.9, 0.9)

            Rectangle(
                pos=(cx - 120, cy - 100),
                size=(240, 50)
            )

            # ------------------------------------------------
            # BLANKET
            # ------------------------------------------------

            Color(0.15, 0.25, 0.45, 0.9)

            Rectangle(
                pos=(cx - 150, cy - 220),
                size=(300, 130)
            )

            # ------------------------------------------------
            # HEAD
            # ------------------------------------------------

            Color(0.85, 0.7, 0.6, 1)

            Ellipse(
                pos=(cx - 45, cy - 90),
                size=(90, 90)
            )

            # ------------------------------------------------
            # HAIR
            # ------------------------------------------------

            Color(0.1, 0.08, 0.05, 1)

            Ellipse(
                pos=(cx - 50, cy - 65),
                size=(100, 50)
            )

            # =================================================
            # NORMAL
            # =================================================

            if self.state == "aware":

                Color(0.1, 0.1, 0.1, 1)

                Line(
                    circle=(cx - 20, cy - 55, 10, 200, 340),
                    width=2
                )

                Line(
                    circle=(cx + 20, cy - 55, 10, 200, 340),
                    width=2
                )

                Line(
                    points=[
                        cx - 12, cy - 75,
                        cx + 12, cy - 75
                    ],
                    width=2
                )

            # =================================================
            # SMALL SCARE
            # =================================================

            elif self.state == "scared_low":

                Color(1, 1, 1, 1)

                Ellipse(
                    pos=(cx - 30, cy - 58),
                    size=(20, 20)
                )

                Ellipse(
                    pos=(cx + 10, cy - 58),
                    size=(20, 20)
                )

                Color(0, 0, 0, 1)

                Ellipse(
                    pos=(cx - 23, cy - 52),
                    size=(6, 6)
                )

                Ellipse(
                    pos=(cx + 17, cy - 52),
                    size=(6, 6)
                )

                Ellipse(
                    pos=(cx - 8, cy - 80),
                    size=(16, 14)
                )

            # =================================================
            # MEDIUM SCARE
            # =================================================

            elif self.state == "scared_mid":

                Color(1, 1, 1, 1)

                Ellipse(
                    pos=(cx - 32, cy - 58),
                    size=(24, 24)
                )

                Ellipse(
                    pos=(cx + 8, cy - 58),
                    size=(24, 24)
                )

                Color(0, 0, 0, 1)

                Ellipse(
                    pos=(cx - 24, cy - 50),
                    size=(8, 8)
                )

                Ellipse(
                    pos=(cx + 16, cy - 50),
                    size=(8, 8)
                )

                Line(
                    points=[
                        cx - 35, cy - 28,
                        cx - 10, cy - 25
                    ],
                    width=3
                )

                Line(
                    points=[
                        cx + 10, cy - 25,
                        cx + 35, cy - 28
                    ],
                    width=3
                )

                Color(0.2, 0.05, 0.05, 1)

                Ellipse(
                    pos=(cx - 12, cy - 82),
                    size=(24, 22)
                )

            # =================================================
            # EXTREME SCARE
            # =================================================

            else:

                Color(1, 0.9, 0.8, 1)

                Ellipse(
                    pos=(cx - 36, cy - 60),
                    size=(28, 30)
                )

                Ellipse(
                    pos=(cx + 8, cy - 60),
                    size=(28, 30)
                )

                Color(0, 0, 0, 1)

                Ellipse(
                    pos=(cx - 24, cy - 48),
                    size=(4, 4)
                )

                Ellipse(
                    pos=(cx + 20, cy - 48),
                    size=(4, 4)
                )

                Line(
                    points=[
                        cx - 38, cy - 22,
                        cx - 10, cy - 20
                    ],
                    width=4
                )

                Line(
                    points=[
                        cx + 10, cy - 20,
                        cx + 38, cy - 22
                    ],
                    width=4
                )

                Color(0.3, 0, 0, 1)

                Ellipse(
                    pos=(cx - 16, cy - 86),
                    size=(32, 28)
                )

                Color(0.3, 0.7, 1.0, 1)

                Ellipse(
                    pos=(cx + 35, cy - 35),
                    size=(10, 16)
                )


# ============================================================
# MAIN GAME
# ============================================================

class HorrorSelfieAnalyzerApp(FloatLayout):

    def __init__(self, **kwargs):

        super().__init__(**kwargs)

        # ----------------------------------------------------
        # CAMERA
        # ----------------------------------------------------

        self.camera = Camera(
            index=1,
            play=True,
            resolution=(320, 240),
            size_hint=(1, 1)
        )

        self.add_widget(self.camera)

        # ----------------------------------------------------
        # HUMAN OVERLAY
        # ----------------------------------------------------

        self.human_overlay = BedHumanOverlay(
            size_hint=(1, 1)
        )

        self.add_widget(self.human_overlay)

        # ----------------------------------------------------
        # STATUS
        # ----------------------------------------------------

        self.rank_label = Label(

            text=(
                "STATUS: WATCHING...\n"
                "MOVE SLOWLY... THEN JERK!"
            ),

            font_size='15sp',
            bold=True,

            halign='center',

            pos_hint={
                'center_x': 0.5,
                'top': 0.98
            },

            size_hint=(1, 0.15),

            color=(1, 0.8, 0.2, 1)
        )

        self.add_widget(self.rank_label)

        # ----------------------------------------------------
        # SOUNDS
        # ----------------------------------------------------

        self.bg_music = SoundLoader.load(
            'The Horror House.ogg'
        )

        self.scream_sound = SoundLoader.load(
            'scream.mp3'
        )

        if self.bg_music:

            self.bg_music.loop = True
            self.bg_music.play()

        # ----------------------------------------------------
        # MOTION DATA
        # ----------------------------------------------------

        self.prev_pixels = None

        # Store recent movement amounts.
        # This lets us compare normal movement
        # against sudden movement.

        self.motion_history = deque(
            maxlen=8
        )

        self.is_scared = False

        self.scare_timer = 0

        # ----------------------------------------------------
        # START CAMERA ANALYSIS
        # ----------------------------------------------------

        Clock.schedule_interval(
            self.analyze_selfie_frame,
            0.1
        )


    # ========================================================
    # CAMERA ANALYSIS
    # ========================================================

    def analyze_selfie_frame(self, dt):

        # ----------------------------------------------------
        # JUMP SCARE ACTIVE
        # ----------------------------------------------------

        if self.is_scared:

            self.scare_timer += dt

            if self.scare_timer > 3.5:

                self.is_scared = False

                self.scare_timer = 0

                self.human_overlay.set_scare_state(
                    "aware"
                )

                self.rank_label.text = (
                    "STATUS: WATCHING...\n"
                    "MOVE SLOWLY... THEN JERK!"
                )

                self.rank_label.color = (
                    1,
                    0.8,
                    0.2,
                    1
                )

                if self.scream_sound:

                    self.scream_sound.stop()

                if self.bg_music:

                    if self.bg_music.state != 'play':

                        self.bg_music.play()

            return

        # ----------------------------------------------------
        # GET CAMERA
        # ----------------------------------------------------

        texture = self.camera.texture

        if not texture:
            return

        pixels = texture.pixels

        size = texture.size

        # ----------------------------------------------------
        # CONVERT TO GRAYSCALE
        # ----------------------------------------------------

        pil_img = PILImage.frombytes(
            mode='RGBA',
            size=size,
            data=pixels
        ).convert('L')

        # ----------------------------------------------------
        # SMALL MOTION GRID
        # ----------------------------------------------------

        gw = 16
        gh = 12

        pil_img = pil_img.resize(
            (gw, gh)
        )

        current_pixels = list(
            pil_img.getdata()
        )

        # ----------------------------------------------------
        # FIRST FRAME
        # ----------------------------------------------------

        if self.prev_pixels is None:

            self.prev_pixels = current_pixels

            return

        # ----------------------------------------------------
        # MEASURE MOVEMENT
        # ----------------------------------------------------

        changed_coords = []

        total_difference = 0

        for idx, (
            current,
            previous
        ) in enumerate(
            zip(
                current_pixels,
                self.prev_pixels
            )
        ):

            difference = abs(
                current - previous
            )

            # Ignore tiny camera noise

            if difference > 15:

                x = idx % gw
                y = idx // gw

                changed_coords.append(
                    (x, y)
                )

                total_difference += difference

        num_changes = len(
            changed_coords
        )

        # ----------------------------------------------------
        # SAVE MOVEMENT AMOUNT
        # ----------------------------------------------------

        self.motion_history.append(
            total_difference
        )

        # ----------------------------------------------------
        # NEED SOME MOVEMENT HISTORY
        # ----------------------------------------------------

        if len(self.motion_history) < 5:

            self.prev_pixels = current_pixels

            return

        # ----------------------------------------------------
        # FIND AVERAGE NORMAL MOVEMENT
        # ----------------------------------------------------

        old_motion = list(
            self.motion_history
        )[:-1]

        average_motion = (
            sum(old_motion)
            / len(old_motion)
        )

        # ----------------------------------------------------
        # A SUDDEN SPIKE
        # ----------------------------------------------------

        sudden_spike = (
            total_difference
            > max(
                average_motion * 2.5,
                350
            )
        )

        # ----------------------------------------------------
        # FIND MOVEMENT AREA
        # ----------------------------------------------------

        bounding_area = 0

        if num_changes >= 10:

            xs = [
                p[0]
                for p in changed_coords
            ]

            ys = [
                p[1]
                for p in changed_coords
            ]

            box_w = (
                max(xs)
                - min(xs)
                + 1
            )

            box_h = (
                max(ys)
                - min(ys)
                + 1
            )

            bounding_area = (
                box_w * box_h
            )

        # ----------------------------------------------------
        # IGNORE WHOLE-SCREEN CHANGES
        # ----------------------------------------------------

        global_change = (
            bounding_area > 140
        )

        # ----------------------------------------------------
        # FAST MOVEMENT
        # ----------------------------------------------------

        fast_movement = (
            num_changes >= 12
            and total_difference > 350
            and not global_change
        )

        # ----------------------------------------------------
        # JUMP-SCARE CONDITION
        # ----------------------------------------------------

        if sudden_spike and fast_movement:

            # Bigger movement = stronger scare

            score = (
                total_difference / 10
                + bounding_area * 0.8
            )

            self.trigger_jump_scare(
                score
            )

            # Clear history after scare

            self.motion_history.clear()

        # ----------------------------------------------------
        # SAVE CURRENT FRAME
        # ----------------------------------------------------

        self.prev_pixels = current_pixels


    # ========================================================
    # JUMP SCARE
    # ========================================================

    def trigger_jump_scare(self, score):

        self.is_scared = True

        self.scare_timer = 0

        # ----------------------------------------------------
        # CHOOSE SCARE LEVEL
        # ----------------------------------------------------

        if score >= 180:

            scare_state = "scared_high"

            rank_text = (
                "RANK S — EXTREME JUMP SCARE!"
            )

            text_color = (
                1,
                0,
                0,
                1
            )

        elif score >= 120:

            scare_state = "scared_mid"

            rank_text = (
                "RANK A — UNCANNY JUMP SCARE!"
            )

            text_color = (
                1,
                0.4,
                0,
                1
            )

        else:

            scare_state = "scared_low"

            rank_text = (
                "RANK B — JUMP SCARE!"
            )

            text_color = (
                1,
                0.8,
                0,
                1
            )

        # ----------------------------------------------------
        # CHANGE FACE
        # ----------------------------------------------------

        self.human_overlay.set_scare_state(
            scare_state
        )

        # ----------------------------------------------------
        # SHOW RESULT
        # ----------------------------------------------------

        self.rank_label.text = (
            "!!! JUMP SCARE !!!\n"
            + rank_text
        )

        self.rank_label.color = text_color

        # ----------------------------------------------------
        # STOP MUSIC
        # ----------------------------------------------------

        if self.bg_music:

            self.bg_music.stop()

        # ----------------------------------------------------
        # PLAY SCREAM
        # ----------------------------------------------------

        if self.scream_sound:

            self.scream_sound.stop()

            self.scream_sound.play()


# ============================================================
# APP
# ============================================================

class HorrorMain(App):

    def build(self):

        return HorrorSelfieAnalyzerApp()


# ============================================================
# RUN
# ============================================================

if __name__ == '__main__':

    HorrorMain().run()